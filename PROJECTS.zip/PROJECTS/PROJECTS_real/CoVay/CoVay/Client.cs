﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Drawing;
/*
 StarterForm -> RoomForm -> FormBorad

Client
    -Board
        -matrix
 */

namespace CoVay
{
    public class Client
    {
        public string username;
        public TcpClient tcpClient; // "tcpClient" cung cấp kết nối cho  client thông qua giao thức TCP
        private NetworkStream ns;  // Cung cấp luồng của dữ liệu để truy cập mạng
        public FormBorad formBorad;

        public bool Connect(string usrname)
        {
            try
            {
                tcpClient = new TcpClient();
                tcpClient.Connect(StarterForm.IP, 8888);
                ns = tcpClient.GetStream();
                username = usrname;
                SendUserName();
                Thread thread = new Thread(Receive);
                thread.Start();
                return true;
            }
            catch
            {
                MessageBox.Show("Không thể kết nối đến máy chủ, kiểm tra IP rồi kết nối lại!", "Kết nối thất bại");
                return false;
            }
        }


        // HÀM NHẬN THÔNG TIN GỬI ĐẾN TỪ SERVER                     
        public void Receive()
        {
            // "sr" đọc dữ liệu đc gửi đến
            StreamReader sr = new StreamReader(ns, Encoding.Unicode);
            while (tcpClient.Connected)
            {
                string jsonstr;
                try
                {
                    jsonstr = sr.ReadLine();
                }
                catch
                {
                    break;
                }
                Msg msg = Msg.ToMsg(jsonstr);
                ReceiveMsg(msg);
            }
        }

        /// <summary>
        /// Gửi Message chat cho Server
        /// </summary>
        /// <param name="mess"></param>
        public void SendChat(string mess)
        {
            try
            {
                Msg msg = new Msg(2, 0, mess);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch
            { }
        }

        public void SendKetThuc()
        {
            try
            {
                Msg msg = new Msg(8, 0, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch
            { }
        }

        /// <summary>
        /// Gửi vị trí quân cờ cho Server
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void SendXYStone(int x, int y)
        {
            try
            {
                string str = x.ToString() + "|" + y.ToString();
                Msg msg = new Msg(1, 0, str);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch { }
        }

        /// <summary>
        /// Gửi tên người chơi
        /// </summary>
        public void SendUserName()
        {
            try
            {
                string str = username;
                Msg msg = new Msg(0, 0, str);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch { }
        }

        /// <summary>
        /// Gửi lệnh sẵn sàng
        /// </summary>
        public void SendReadyFight()
        {
            try
            {
                Msg msg = new Msg(5, 0, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch { }
        }

        /// <summary>
        /// Gửi lệnh bỏ lượt
        /// </summary>
        public void SendBoLuot()
        {
            try
            {
                Msg msg = new Msg(3, 0, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch { }
        }

        /// <summary>
        /// Gửi lệnh tạo Room
        /// </summary>
        public void SendCreateRoom()
        {
            try
            {
                Msg msg = new Msg(4, 0, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch
            { }
        }

        /// <summary>
        /// Gửi lệnh vào Room
        /// </summary>
        /// <param name="roomnumber"></param>
        public void SendJoinRoom(int roomnumber)
        {
            try
            {
                string str = roomnumber.ToString();
                Msg msg = new Msg(6, 0, str);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch
            { }
        }

        /// <summary>
        /// Gửi lệnh khi thoát Room
        /// </summary>
        public void SendCloseRoom()
        {
            try
            {
                Msg msg = new Msg(7, 0, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                ns.Write(data, 0, data.Length);
            }
            catch { }
        }

        /// <summary>
        /// Xử lý Msg từ Server
        /// </summary>
        /// <param name="msg"></param>
        public void ReceiveMsg(Msg msg)
        {
            if (msg == null)
            {
                tcpClient.Close();
                return;
            }
            switch (msg.cmd)
            {
                case 0: //Nhận lệnh hiển thị MessageBox
                    string notifi = (string)msg.Object;
                    StarterForm.RF.BeginInvoke(new Action(() =>
                    {
                        MessageBox.Show(notifi, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }));

                    break;

                case 1: //Nhận các vị trí quân cờ server gửi và hiện lên bàn cờ

                    //Ép kiểu về JArray chứa các chuỗi string đã đóng gói bên server
                    JArray listmatrix = (JArray)msg.Object;

                    //Nhận vị trí quân cờ mới đặt để đánh dấu
                    formBorad.board.StoneNum = msg.type; 

                    int i = 0;
                    foreach (string str5 in listmatrix)
                    {
                        //Mỗi string như chứa các giá trị của matrix, mỗi giá trị ngăn cách nhau bởi dâu '|'
                        string[] arrstr3 = str5.Split('|');
                        int n = ConstNumber.linenum + 1;
                        for (int j = 0; j < n; j++)
                        {
                            //đưa các giá trị đó vào matrix trong board
                            //Thay cái bàn cờ bằng cái bàn cờ mà Server gửi
                            formBorad.board.matrix[j, i] = int.Parse(arrstr3[j]);
                        }
                        i++;
                    }
                    StarterForm.RF.BeginInvoke(new Action(() =>
                    {
                        //Draw lại picturebox
                        formBorad.pictureBox1.Invalidate();
                    }));

                    break;

                case 2: //Nhận chat từ server
                    string str2 = (string)msg.Object + "\n";
                    StarterForm.RF.BeginInvoke(new Action(() =>
                    {
                        //hiển thị lên khung chat
                        formBorad.richTextBox1.Text += str2;
                    }));

                    break;
                case 3: //Nhận room từ server

                    // Nếu listroom rỗng thì trảnh bị lỗi
                    if (StarterForm.RF.listViewRoom == null)
                    {
                        return;
                    }

                    //Khi nhận lệnh listroom trống
                    if (msg.type == 1)
                    {
                        StarterForm.RF.BeginInvoke(new Action(() =>
                        {
                            //Xóa các room hiện có trên "listViewRoom"
                            StarterForm.RF.listViewRoom.Items.Clear();
                        }));

                        return;
                    }


                    JArray liststr = (JArray)msg.Object;
                    //Chuyển JArray string thành các item ListView và cập nhập ListView
                    StarterForm.RF.BeginInvoke(new Action(() =>
                    {
                        StarterForm.RF.listViewRoom.Items.Clear();
                        foreach (string str5 in liststr)
                        {
                            string[] arrstr1 = str5.Split('|');
                            int roomnum = int.Parse(arrstr1[0]);
                            string mastername = arrstr1[1];
                            int countplayer = int.Parse(arrstr1[2]);
                            ListViewItem item = new ListViewItem(new string[] { roomnum.ToString(), mastername, countplayer.ToString() });
                            StarterForm.RF.listViewRoom.Items.Add(item);
                        }
                    }));

                    break;
                case 4:
                    StarterForm.RF.BeginInvoke(new Action(() =>
                    {
                        StarterForm.RF.label2.Text = msg.type.ToString();
                    }));

                    break;
                case 5:
                    break;
                case 6: //Nhận lệnh tạo formboard

                    StarterForm.RF.BeginInvoke(new Action(() =>
                        {
                            formBorad = new FormBorad();
                            // tên cửa sổ
                            formBorad.Text = username;
                            formBorad.Show();
                        }));
                    break;

                case 7:

                    int type = msg.type;

                    if (type == 0) //Tắt hiển thị thời gian
                    {
                        StarterForm.RF.BeginInvoke(new Action(() =>
                        {
                            formBorad.LabelTime.Visible = false;
                            formBorad.LabelTime.Text = "120";
                            formBorad.timer1.Stop();
                            formBorad.TimeOutInt = 120;
                        }));
                    }

                    else if (type == 1) //Hiển thị thời gian
                    {
                        StarterForm.RF.BeginInvoke(new Action(() =>
                        {
                            formBorad.LabelTime.Visible = true;
                            formBorad.LabelTime.Text = "120";
                            formBorad.TimeOutInt = 120;
                            formBorad.timer1.Start();
                            formBorad.LabelTime.ForeColor = Color.Green;

                        }));
                    }
                    break;
            }
        }
    }
}
