﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;

namespace CoVayServer
{
    public class Player
    {
        public string name;

        public Socket socket;

        public bool Isblack;

        public bool readyFight;

        public bool inTurn;

        public int roomNumber;
        public Player(Socket socKet)
        {
            socket = socKet;
            roomNumber = 0;
        }
    }
}
