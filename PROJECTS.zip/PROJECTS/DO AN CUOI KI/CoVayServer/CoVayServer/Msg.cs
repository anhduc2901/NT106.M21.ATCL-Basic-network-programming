﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace CoVayServer
{
    public class Msg
    {
        public int cmd;
        public int type;
        public object Object;

        public Msg(int Cmd, int t, object o)
        {
            cmd = Cmd;
            type = t;
            Object = o;
        }

        /// <summary>
        /// Serialize Msg thành string
        /// </summary>
        /// <returns></returns>
        public string ToJson()
        {
            string str = JsonConvert.SerializeObject(this);
            return str;
        }

        /// <summary>
        /// DeSerialize sting thành Msg
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static Msg ToMsg(string str)
        {
            Msg msg;
            try
            {
                msg = JsonConvert.DeserializeObject<Msg>(str);
            }
            catch
            {
                return null;
            }
            return msg;
        }
    }
}
