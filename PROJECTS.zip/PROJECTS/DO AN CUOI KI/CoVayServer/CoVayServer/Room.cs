﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Sockets;
using System.IO;
using Newtonsoft.Json.Linq;

namespace CoVayServer
{
    public class Room
    {
        public int RoomNumber;

        public Board board;

        public List<Player> ListPlayerinRoom;

        public bool Fight;

        public int SoLuongBoLuot = 0;

        public Room(int roomNumber, Player player)
        {
            ListPlayerinRoom = new List<Player>();
            RoomNumber = roomNumber;
            ListPlayerinRoom.Add(player);
        }

        /// <summary>
        /// Gửi Message của 1 client cho các client trong room
        /// </summary>
        /// <param name="mess"></param>
        public void SendChat(string mess)
        {
            foreach (Player player1 in ListPlayerinRoom)
            {
                try
                {
                    Msg msg = new Msg(2, 0, mess);
                    byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                    player1.socket.Send(bytes);
                }
                catch { }
            }
        }

        /// <summary>
        /// Gửi vị trí các quân cờ cho các client trong bàn cờ
        /// </summary>
        public void SendBoard()
        {
            JArray jArray = new JArray();
            int n = ConstNumber.linenum + 1;
            for (int i = 0; i < n; i++)
            {
                string str = string.Empty;
                for (int j = 0; j < n; j++)
                {
                    str += board.matrix[j, i].ToString();
                    str += "|";
                }
                jArray.Add(str);
            }
            foreach (Player player1 in ListPlayerinRoom)
            {
                try
                {
                    Msg msg = new Msg(1, board.StoneNum, jArray);
                    byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                    player1.socket.Send(bytes);
                }
                catch
                {
                }
            }
        }
    }
}
