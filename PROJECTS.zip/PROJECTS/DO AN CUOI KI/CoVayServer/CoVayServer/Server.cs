﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Net.NetworkInformation;
using System.Web;
using Newtonsoft.Json.Linq;
/*
 Server :
+List player:
    
+List Room :
    -Room       
        -List_player
            -player
        -board
            -matrix
                              
 */
namespace CoVayServer
{
    public partial class Server : Form
    {
        public static List<Player> ListPlayer; //Danh sách player

        public bool listen;

        public static List<Room> ListRoom; //Danh sách Room



        public Server()
        {
            InitializeComponent();
        }


        // Sự kiện nhấn nút Listen
        private void buttonListen_Click(object sender, EventArgs e)
        {
            if (listen)
            {
                AddTextOutput("Server is running");
                return;
            }
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList) //Hiển thị các địa chỉ ip có thể connect đến server
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    string str = "Server turning on: " + ip.ToString() + ":8888";
                    AddTextOutput(str);
                }
            }
            //Tạo luồng nhận lắng nghe kết nối từ client
            Thread thread = new Thread(Listen);
            thread.Start();
        }

        /// <summary>
        /// Lắng nghe kết nối từ client
        /// </summary>
        public void Listen()
        {
            ListPlayer = new List<Player>();
            ListRoom = new List<Room>();
            listen = true;
            new Thread(update).Start(); //Khởi chạy luồng update
            TcpListener tcpListener = new TcpListener(IPAddress.Any, 8888);
            tcpListener.Start();

            while (listen)
            {
                //Khi có 1 client kết nối đến socket sẽ được tạo
                Socket socket = tcpListener.AcceptSocket();

                //Tạo 1 player , player này sẽ là đóng vai trò như 1 client để Server tương tác
                Player player = new Player(socket);

                string str = "New client connect from: " + socket.RemoteEndPoint;
                AddTextOutput(str);

                //Thêm player vào danh sách
                ListPlayer.Add(player);

                Thread thread = new Thread(ListenPlayer); //Tạo luồng nhận Msg client gửi
                thread.Start(player);
            }
        }

        /// <summary>
        /// Nhận Msg từ client
        /// </summary>
        /// <param name="obj"></param>
        public void ListenPlayer(object obj)
        {
            Player player = (Player)obj;
            NetworkStream stream = new NetworkStream(player.socket);
            StreamReader streamReader = new StreamReader(stream, Encoding.Unicode);
            while (player.socket.Connected)
            {
                string str;
                try
                {
                    //Nhận string từ client
                    str = streamReader.ReadLine();
                }
                catch
                {
                    return;
                }

                Msg msg = Msg.ToMsg(str); //Chuyển string thành msg để xử lý

                ReceiveMsg(msg, player); //Xử lý dữ liệu nhận được
            }
        }

        /// <summary>
        /// Luồng update
        /// </summary>
        public void update()
        {
            while (listen)
            {
                UpdateListRoom();
                UpdateListViewRoom();
                UpdateListPlayer();
                SendListRoom(); //Gửi danh sách phòng cho các client
                SendPlayerNumber(); //Gửi số player đang online

                Thread.Sleep(5000); //Sau mỗi 5s các lệnh bên trên được thực hiện lại
            }
        }

        //Cập nhật danh sách player
        public void UpdateListPlayer()
        {
            //Nếu player nào bị mất kết nối thì xóa khỏi ListPlayer
            for (int i = 0; i < ListPlayer.Count; i++)
            {
                Player player = ListPlayer[i];
                if (!player.socket.Connected)
                {
                    ListPlayer.Remove(player);
                }
            }
            //Cập nhật listBoxListPlayer
            listBoxListPlayer.BeginInvoke(new Action(() =>
            {
                listBoxListPlayer.Items.Clear();
                foreach (Player player in ListPlayer)
                {
                    listBoxListPlayer.Items.Add(player.name);
                }
            }));
        }

        //Cập nhật danh sách phòng
        public void UpdateListRoom()
        {
            for (int i = 0; i < ListRoom.Count; i++)
            {
                Room room = ListRoom[i];
                //Nếu player nào bị mất kết nối thì xóa khỏi ListPlayerinRoom
                for (int j = 0; j < room.ListPlayerinRoom.Count; j++)
                {
                    Player player = room.ListPlayerinRoom[j];
                    if (!player.socket.Connected)
                    {
                        room.ListPlayerinRoom.Remove(player);
                    }
                }
                //Nếu Room không còn player nào thì bị xóa
                if (room.ListPlayerinRoom.Count <= 0)
                {
                    ListRoom.Remove(room);
                }
            }
        }

        //Cập nhật listViewRoom
        public void UpdateListViewRoom()
        {
            listViewRoom.BeginInvoke(new Action(() =>
            {
                listViewRoom.Items.Clear();
                foreach (Room r in ListRoom)
                {
                    ListViewItem item = new ListViewItem(new string[] { r.RoomNumber.ToString(), r.ListPlayerinRoom[0].name, r.ListPlayerinRoom.Count.ToString() });
                    listViewRoom.Items.Add(item);
                }
            }));
        }

        public void SendPlayerNumber()
        {
            foreach (Player player in ListPlayer)
            {
                try
                {
                    Msg msg = new Msg(4, ListPlayer.Count, null);
                    byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                    player.socket.Send(bytes);
                }
                catch { }
            }
        }

        /// <summary>
        /// Hiển thị MessBox bên client bằng server
        /// </summary>
        /// <param name="mess"></param>
        /// <param name="player"></param>
        public void SendMessageBox(string mess, Player player)
        {
            try
            {
                Msg msg = new Msg(0, 0, mess);
                byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                player.socket.Send(bytes);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Gửi danh sách Room
        /// </summary>
        public void SendListRoom()
        {
            //Nếu danh sách room trống gửi lệnh xóa listviewroom bên client
            if (ListRoom.Count <= 0)
            {
                foreach (Player player in ListPlayer)
                {
                    try
                    {
                        Msg msg = new Msg(3, 1, null);
                        byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                        player.socket.Send(bytes);
                    }
                    catch { }
                }
                return;
            }

            JArray list = new JArray(); //Tạo 1 JArray để chứa danh sách chuỗi
            foreach (Room room in ListRoom)
            {
                string str = room.RoomNumber + "|" + room.ListPlayerinRoom[0].name + "|" + room.ListPlayerinRoom.Count;
                list.Add(str);
            }
            foreach (Player player in ListPlayer)
            {
                try
                {
                    Msg msg = new Msg(3, 0, list);
                    byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                    player.socket.Send(bytes);
                }
                catch
                {
                }
            }
        }

        public void SendResetBoard()
        {
            foreach (Player player in ListPlayer)
            {
                try
                {
                    Msg msg = new Msg(5, 0, null);
                    byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                    player.socket.Send(bytes);
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Gửi lệnh để client hiển thị form bàn cờ bên client
        /// </summary>
        /// <param name="player"></param>
        public void SendShowBoard(Player player)
        {
            try
            {
                Msg msg = new Msg(6, 0, null);
                byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                player.socket.Send(bytes);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Gửi lệnh set thời gian cho client
        /// </summary>
        /// <param name="player"></param>

        public void SendSetTime(Player player, int type)
        {
            try
            {
                Msg msg = new Msg(7, type, null);
                byte[] bytes = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                player.socket.Send(bytes);
            }
            catch { }
        }

        /// <summary>
        /// Xử lý dữ liệu từ client
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="player"></param>
        public void ReceiveMsg(Msg msg, Player player)
        {
            //Dữ liệu rỗng thì đóng "Socket": Nơi trao đổi dữ liệu giữa client và Server
            if (msg == null)
            {
                player.socket.Close();
                return;
            }
            //Dựa vào kí hiệu mà Client gửi đến sẽ có các cách xử lý khác nhau
            switch (msg.cmd)
            {
                case 0: //Set tên player
                    player.name = (string)msg.Object;
                    break;

                case 1: // Nhận tọa độ quân cờ từ Client

                    Room room4 = GetRoom(player.roomNumber); //Room của player

                    if (room4 == null)
                    {
                        break;
                    }

                    //Nếu trận đấu chưa bắt đầu thì không thực hiện các câu lệnh bên dưới
                    if (!room4.Fight)
                    {
                        SendMessageBox("Trận đấu chưa bắt đầu", player);
                        break;
                    }

                    //Nếu player chưa đến lượt player đánh thì không thực hiện các câu lệnh bên dưới
                    if (!player.inTurn)
                    {
                        SendMessageBox("Chưa đến lượt bạn :(", player);
                        break;
                    }

                    //Nếu chỉ 1 người nhấn bỏ lượt mà người còn lại đánh tiếp thì "SoLuongBoLuot" sẽ = 0 
                    room4.SoLuongBoLuot = 0;


                    string text3 = (string)msg.Object;
                    string[] array2 = text3.Split('|');
                    int x = int.Parse(array2[0]);
                    int y = int.Parse(array2[1]);

                    //Nếu như đặt quân cờ không thỏa các điều kiện luật thì break
                    if (!room4.board.SetStone(player.Isblack, x, y))
                    {
                        break;
                    }

                    //Bỏ lượt đánh của player
                    player.inTurn = false;

                    //Cho timer của người vừa đánh dừng lại
                    SendSetTime(player, 0);

                    //Set lượt đánh của player khác trong room
                    foreach (Player player1 in room4.ListPlayerinRoom)
                    {
                        if (player1 != player)
                        {
                            player1.inTurn = true;
                            SendSetTime(player1, 1);
                        }
                    }


                    //AddTextOutput("Player: " + player.name + " .Room: " + player.roomNumber + " .X: " + x + " .Y: " + y);
                    room4.SendBoard();

                    break;

                case 2: //Nhận chat từ player
                    string mess2 = player.name + ": " + (string)msg.Object;
                    Room room2 = GetRoom(player.roomNumber);
                    if (room2 != null)
                    {
                        room2.SendChat(mess2); //Gửi lại cho các player trong room
                    }
                    break;

                case 3: //  Nhận tín hiệu bỏ lượt từ player

                    Room room5 = GetRoom(player.roomNumber);

                    if (room5 == null)
                    {
                        break;
                    }
                    if (!room5.Fight) //Trận đấu chưa bắt đầu mà nhấn bỏ lượt thì break
                    {
                        SendMessageBox("Trận đấu chưa bắt đầu", player);
                        break;
                    }
                    if (!player.inTurn) //Nếu player không phải là người đánh mà nhấn bỏ lượt thì break
                    {
                        SendMessageBox("Chưa đến lượt bạn :(", player);
                        break;
                    }

                    player.inTurn = false;
                    SendSetTime(player, 0);

                    string mess3 = player.name + " ĐÃ BỎ LƯỢT";

                    room5.SoLuongBoLuot++;

                    if (room5.SoLuongBoLuot == 2)
                    {
                        room5.SendChat("Trận đấu kết thúc do cả 2 đã bỏ lượt");

                        if (room5.board.white_killed > room5.board.black_killed)
                        {
                            SendMessageBox("Bạn đã thắng!!!", room5.ListPlayerinRoom[0]);
                            SendMessageBox("Bạn đã thua!!!", room5.ListPlayerinRoom[1]);
                        }
                        else if (room5.board.white_killed == room5.board.black_killed)
                        {
                            foreach (Player player1 in room5.ListPlayerinRoom)
                            {
                                SendMessageBox("HÒA !!!!!!!!!!!!!!!", player1);
                            }
                        }
                        else
                        {
                            SendMessageBox("Bạn đã thắng!!!", room5.ListPlayerinRoom[1]);
                            SendMessageBox("Bạn đã thua!!!", room5.ListPlayerinRoom[0]);
                        }


                        room5.SoLuongBoLuot = 0;
                        room5.board = new Board();
                        SendResetBoard();
                        foreach (Player player1 in room5.ListPlayerinRoom)
                        {
                            player1.readyFight = false;
                            player1.inTurn = false; //Set lại lượt đánh
                            SendSetTime(player1, 0);
                        }
                        room5.Fight = false;

                        return;
                    }





                    room5.SendChat(mess3); //Gửi mess hiển thị player này bỏ lượt cho player khác


                    //Set lại lượt đánh cho player khác
                    foreach (Player player1 in room5.ListPlayerinRoom)
                    {

                        if (player1 != player)
                        {
                            player1.inTurn = true;
                            SendSetTime(player1, 1);
                        }
                    }




                    break;

                case 4: //Nhận lệnh tạo room
                    if (CheckPlayerinOderRoom(player))
                    {
                        SendMessageBox("Bạn đang ở trong phòng khác!", player);
                        break;
                    }
                    int int3 = 0;
                    for (int i = 0; i < 100; i++)
                    {
                        if (!CheckNumRoom(i)) //Kiểm tra số phòng có bị trùng
                        {
                            int3 = i;
                            break;
                        }
                    }
                    Room room = new Room(int3, player); //Tạo phòng mới
                    player.roomNumber = room.RoomNumber; //Set số phòng cho player

                    ListRoom.Add(room); //Thêm phòng này vào danh sách

                    SendShowBoard(player);
                    break;

                case 5: //Nhận lệnh khi nhấn nút sẵn sàng từ client

                    if (player.readyFight) //player đã sẵn sàng
                    {
                        SendMessageBox("Bạn đã sẵn sàng rồi", player);
                        break;
                    }

                    Room room6 = GetRoom(player.roomNumber);
                    if (room6 == null)
                    {
                        break;
                    }

                    player.readyFight = true;
                    string mess = player.name + " ĐÃ SẴN SÀNG";
                    room6.SendChat(mess); //Gửi tin nhắn đã sẵn sàng

                    if (player == room6.ListPlayerinRoom[0])
                    {
                        player.Isblack = true; //Player đầu tiên là quân đen
                        player.inTurn = true; //và đánh lượt đầu
                    }
                    else
                    {
                        player.Isblack = false; //Player còn lại là quân trắng
                        player.inTurn = false; //và đánh lượt sau
                    }

                    int num = 0;
                    foreach (Player item2 in room6.ListPlayerinRoom)
                    {
                        if (item2.readyFight)
                        {
                            num++;
                        }
                    }
                    if (num >= 2) //Nếu 2 Player sẵn sàng thì bắt đầu ván đấu
                    {
                        room6.board = new Board(); //Tạo bàn cờ
                        room6.Fight = true;
                        SendSetTime(room6.ListPlayerinRoom[0], 1);
                        room6.SendChat("Trận đấu bắt đầu!!!!");
                    }
                    break;

                case 6: //Nhận lệnh join room
                    if (CheckPlayerinOderRoom(player))  //Kiểm tra player có ở trong room khác
                    {
                        SendMessageBox("Bạn đang ở trong phòng khác!", player);
                        break;
                    }

                    int roomnum = int.Parse((string)msg.Object);

                    Room room7 = GetRoom(roomnum);
                    if (room7 == null)
                    {
                        break;
                    }

                    if (room7.ListPlayerinRoom.Count >= 2) //Nếu phòng đã có 2 người hoặc nhiều hơn thì k cho vào nữa
                    {
                        SendMessageBox("Phòng đã đầy", player);
                        break;
                    }

                    //Set số phòng cho player
                    player.roomNumber = roomnum;

                    room7.ListPlayerinRoom.Add(player);

                    SendShowBoard(player);

                    break;
                case 7: //Nhận lệnh rời phòng, set lại các thuộc tính khi player chưa vào phòng nào
                    Room room8 = GetRoom(player.roomNumber);

                    room8.board = new Board(); //Vì 1 player thoát nên bàn cờ sẽ được tạo lại

                    SendResetBoard();

                    foreach (Player player1 in room8.ListPlayerinRoom)
                    {
                        player1.readyFight = false;
                        player1.inTurn = false; //Set lại lượt đánh
                        SendSetTime(player1, 0);
                        if (player1 != player)
                        {
                            SendMessageBox("Người chơi " + player.name + " đã rời phòng", player1);
                        }
                    }

                    room8.Fight = false;
                    room8.ListPlayerinRoom.Remove(player); //Xóa player trong phòng
                    player.roomNumber = 0;

                    break;

                case 8:
                    Room room9 = GetRoom(player.roomNumber);

                    room9.board = new Board();

                    SendResetBoard();
                    room9.SendChat("Vì " + player.name + " hết thời gian nên trận đấu kết thúc");

                    foreach (Player player1 in room9.ListPlayerinRoom)
                    {
                        player1.readyFight = false;
                        player1.inTurn = false; //Set lại lượt đánh

                        SendSetTime(player1, 0);
                        
                        if (player1 != player)
                        {
                            SendMessageBox("Bạn đã thắng!!!", player1);
                        }
                        else
                        {
                            SendMessageBox("Bạn đã thua!!!", player);
                        }
                    }

                    room9.Fight = false;


                    break;


            }
        }

        /// <summary>
        /// Kiểm tra player này có đang ở trong 1 room nào đó
        /// </summary>
        /// <param name="player"></param>
        /// <returns>true nếu player này đang ở trong 1 phòng nào đó</returns>
        public bool CheckPlayerinOderRoom(Player player)
        {
            foreach (Room room1 in ListRoom)
            {
                foreach (Player player1 in room1.ListPlayerinRoom)
                {
                    if (player1 == player)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Nhận về Room trong listRoom bằng số phòng
        /// </summary>
        /// <param name="RoomNum"></param>
        /// <returns>Room trong ListRoom, null nếu không tìm thấy</returns>
        public static Room GetRoom(int RoomNum)
        {
            foreach (Room room in ListRoom)
            {
                if (room.RoomNumber == RoomNum)
                {
                    return room;
                }
            }
            return null;
        }

        /// <summary>
        /// Kiểm tra số phòng có bị trùng
        /// </summary>
        /// <param name="num"></param>
        /// <returns>true nếu đã sử dụng, false ngược lại</returns>
        public bool CheckNumRoom(int num)
        {
            foreach (Room room in ListRoom)
            {
                if (room.RoomNumber == num)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Thêm output vào ListBoxOut
        /// </summary>
        /// <param name="cmd"></param>
        public void AddTextOutput(string cmd)
        {
            richTextBoxOutput.BeginInvoke(new Action(() =>
            {
                richTextBoxOutput.Text += cmd + "\n";
            }));
        }


        /// <summary>
        /// Đóng server
        /// </summary>
        public void StopServer()
        {
            listen = false;
            Environment.Exit(0);
        }

        //Sự kiện nút Stop
        private void buttonStop_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn tắt server?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                StopServer();
            }
        }

        // Sự kiện khi nhân nút X
        private void Server_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn tắt server?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                StopServer();
            }
            else
            {
                e.Cancel = true; //Nếu nhấn nút No thì không tắt
            }
        }

        private void Server_Load(object sender, EventArgs e)
        {

        }
    }
}
