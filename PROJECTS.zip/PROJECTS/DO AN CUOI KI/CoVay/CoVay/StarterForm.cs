﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoVay
{
    public partial class StarterForm : Form
    {
        public static string IP = "127.0.0.1";
        public static RoomForm RF;
        public static Client client;

        public StarterForm()
        {
            InitializeComponent();
        }

        //Sự kiện nút Connect
        private void button_Connect_Click(object sender, EventArgs e)
        {
            Connect();
        }

        public void Connect()
        {
            // Kiểm tra nếu Username rỗng thì thông báo
            if (textBox_UserName.Text == string.Empty)
            {
                MessageBox.Show("Vui lòng nhập User Name!");
                return;
            }

            IP = textBoxIP.Text;

            //Tạo client gửi, nhận dữ liệu từ server
            client = new Client();

            //Nếu client không connect được thì sẽ hiện lên thông báo
            if (!client.Connect(textBox_UserName.Text))
            {
                return;
            }

            textBoxIP.Enabled = false;
            textBox_UserName.Enabled = false;

            //Tạo RoomForm
            RF = new RoomForm();
            //Hiển thị RoomForm
            RF.Show();
        }

        private void StarterForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (client != null)
            {
                client.tcpClient.Close();
            }
        }

        private void StarterForm_Load(object sender, EventArgs e)
        {

        }
    }
}
