﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace CoVay
{
    public partial class FormBorad : Form
    {
        public Board board;
        public int TimeOutInt = 120;

        public FormBorad()
        {
            InitializeComponent();
            board = new Board();
            LabelTime.Visible = false;
            //Chưa bắt đầu thì k cho chạy timer
            timer1.Stop();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            board.DrawBoard(g);
            board.DrawStones(g);
        }

        /// <summary>
        /// Sự kiện khi nhấn chuột trên bảng pictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                //Nếu click chuột trái
                if (e.Button == MouseButtons.Left)
                {
                    int boardsize = ConstNumber.linenum;

                    double dbX = e.X * 1.0 / ConstNumber.cellSize - 0.5;

                    // Nếu không click chuẩn vào các điểm giao nhau thì hàm này sẽ cho tọa độ của điểm giao nhau gần nhất
                    int intX = GetUpperNum(dbX);

                    double dbY = e.Y * 1.0 / ConstNumber.cellSize - 0.5;
                    // Nếu không click chuẩn vào các điểm giao nhau thì hàm này sẽ cho tọa độ của điểm giao nhau gần nhất
                    int intY = GetUpperNum(dbY);

                    //Nếu click không ở trên bàn cờ sẽ return
                    if (intX > boardsize || intY > boardsize) return;
                    if (intX == 0 || intY == 0) return;

                    //Gửi tọa độ  đến cho Server
                    StarterForm.client.SendXYStone(intX, intY);
                }
            }
            catch
            {
            }
        }

        private int GetUpperNum(double a)
        {
            int b = (int)a;
            if (b < a)
            {
                b += 1;
            }
            return b;
        }

        /// <summary>
        /// Sự kiện nút Chat
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSendMess_Click(object sender, EventArgs e)
        {
            StarterForm.client.SendChat(textBox_Chat.Text);
            textBox_Chat.Text = "";
        }

        /// <summary>
        /// Sự kiện nút sẵn sàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonReady_Click(object sender, EventArgs e)
        {
            StarterForm.client.SendReadyFight();
        }

        /// <summary>
        /// Sự kiện nút bỏ lượt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBoLuot_Click(object sender, EventArgs e)
        {
            StarterForm.client.SendBoLuot();
        }

        /// <summary>
        /// Đếm thời gian
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeOutInt--;
            LabelTime.Text = TimeOutInt.ToString();
            if (TimeOutInt == 119)
            {
                LabelTime.ForeColor = Color.Green;
            }
            else if (TimeOutInt == 89)
            {
                LabelTime.ForeColor = Color.Yellow;
            }
            else if (TimeOutInt == 29)
            {
                LabelTime.ForeColor = Color.Red;
            }
            else if (TimeOutInt <= 0)
            {
                StarterForm.client.SendKetThuc();
                TimeOutInt = 120;
                timer1.Stop();
            }
        }



        /// <summary>
        /// Sự kiện bấm nút CLose
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonClose_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn rời phòng này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                StarterForm.client.SendCloseRoom();
                Dispose();
                Close();
            }
        }

        /// <summary>
        /// Sự kiện bấm nút X
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormBorad_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Bạn có muốn rời phòng này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                StarterForm.client.SendCloseRoom();
                Dispose();
                Close();
            }
            else
            {
                //Nếu nhấn No thì không thoát form
                e.Cancel = true;
            }
        }

        private void textBox_Chat_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                StarterForm.client.SendChat(textBox_Chat.Text);
                textBox_Chat.Text = "";
            }
        }

        private void FormBorad_Load(object sender, EventArgs e)
        {

        }
    }
}
