﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoVay
{
    public static class ConstNumber
    {
        public const int linenum = 13;
        public const int cellSize = 30;
    }
}
