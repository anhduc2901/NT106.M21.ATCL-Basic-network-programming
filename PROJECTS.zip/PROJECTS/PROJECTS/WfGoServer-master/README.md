# wf GO server  

wf GO client:  https://github.com/wffanstorm/WfGoClient

this server proj is used to supporting muti client's online play. 