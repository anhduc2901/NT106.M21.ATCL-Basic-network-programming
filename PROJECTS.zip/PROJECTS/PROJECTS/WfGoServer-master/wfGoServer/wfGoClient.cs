﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Windows.Forms;

namespace wfGoServer
{
    class wfGoClient
    {
        // bàn cờ 
        public Board board;
        // người chơi
        public FightPlayer player;

        // trạng thái của thằng ng chơi
        public int heart;

        // Cung cấp các kết nối máy khách cho các dịch vụ mạng TCP.
        public TcpClient tcp;

        public NetworkStream netstream;
        
        public StreamReader streamreader;

        public Thread ListenThread;

        public Thread HeartSubThread;

        public Form1 frm;

        public wfGoServer server;

        public wfGoClient(string name, wfGoServer svr, Form1 f)
        {
            // Client có bàn cờ
            board = new FightBoard();
            // tên của người chơi
            player = new FightPlayer(name, this);

            tcp = new TcpClient();


            heart = ConstNumber.heart;

            frm = f;

            server = svr;

        }

        public void Connect()
        {
            string ip = ConstNumber.serverIP;
            int port = ConstNumber.serverport;

            tcp.Connect(ip, port);

        }

        public void SendMSG(MSG msg)
        {
            
            //try
            //{
                netstream = tcp.GetStream();
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
                if(msg.type== MSG_Type.ApplyFight)
                {
                    //MessageBox.Show("transfer apply fight to " + player.name, "server");
                }
                /*
            }
            catch (Exception ex)
            {
                return;
            }
            */
        }

        // Gửi các thông tin "b" có ở Server sang các Client        :               DONEEEEEEE
        public void SendBroadcastMSG(Broadcast b)
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.Broadcast, b);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }

        public void SendApplyFightMSG(int minute)
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.ApplyFight, minute);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }

        public void SendIfAgreeMSG(bool ifagree, string target)
        {
            try
            {
                netstream = tcp.GetStream();
                string param = ifagree.ToString() + "_" + target;
                MSG msg = new MSG(MSG_Type.IfAgree, param);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }
        public void SendRoomMSG(Room room)
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.Room, room);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                MessageBox.Show("err in send room msg: "+ex.Message);
                return;
            }
        }
        public void SendBoardMSG()
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.Board, board);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }
        public void SendRegretMSG()
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.Regret, board);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }
        public void SendSurrenderMSG()
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.Surrender, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }
        public void SendFinishMSG()
        {
            try
            {
                netstream = tcp.GetStream();
                MSG msg = new MSG(MSG_Type.Finish, null);
                byte[] data = Encoding.Unicode.GetBytes(msg.ToJson() + "\r\n");
                netstream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                return;
            }

        }

        // Đây là 1 thread 
        private void Listen()
        {
            // "streamreader" để đọc dữ liệu đc gửi đến
            streamreader = new StreamReader(tcp.GetStream(), Encoding.Unicode);

            //Khi vẫn còn đang kết nối sẽ nhận các luồng từ Server gửi dến
            while (tcp.Connected)
            {
                
                string jsonstr;
                try
                {
                    // dữ liệu gửi đến dưới dạng "string"
                    // đọc dữ liệu gửi đến và lưu vào "jsonstr"
                    jsonstr = streamreader.ReadLine();
                }
                catch (Exception ex)
                {
                    break;
                }
                // chuyển đổi dữ liệu từ string sang kiểu "MSG"
                MSG msg = MSG.Parse(jsonstr);

                //xử lý tin nhắn
                DealMSG(msg);
            }
        }


        private void DealMSG(MSG msg)
        {
            if (msg == null) //ngắt kết nối
            {
                tcp.Close();
                return;
            }
            

            switch (msg.type)
            {
                case MSG_Type.Name:
                    DealNameMSG(msg);
                    break;
                case MSG_Type.Heartbeat:
                    DealHeartBeatMSG();
                    break;
                case MSG_Type.CreatRoom:
                    DealCreatRoomMSG(msg);
                    break;
                case MSG_Type.ComeInRoom:
                    DealComeInRoomMSG(msg);
                    break;
                case MSG_Type.QuitRoom:
                    DealQuitRoomMSG();
                    break;
                case MSG_Type.ApplyFight:
                    DealApplyFightMSG(msg);
                    break;
                case MSG_Type.Board:
                    DealBoardMSG(msg);
                    break;
                case MSG_Type.Regret:
                    DealRegretMSG(msg);
                    break;
                case MSG_Type.Finish:
                    DealFinishMSG(msg);
                    break;
                case MSG_Type.Surrender:
                    DealSurrenderMSG(msg);
                    break;
                case MSG_Type.IfAgree:
                    DealIfAgreeMSG(msg);
                    break;


            }
        }

        private void DealNameMSG(MSG msg)
        {
            player.name = (string)msg.parameter;
            frm.ListBox1.BeginInvoke(new Action(() => frm.ListBox1.Items.Add(player.name)));
            frm.LblOnLineNum.BeginInvoke(new Action(() =>
            {
                int n = Convert.ToInt32(frm.LblOnLineNum.Text);
                n++;
                frm.LblOnLineNum.Text = n.ToString();
            }));
        }
        private void DealHeartBeatMSG()
        {
            heart++;
        }
        private void DealCreatRoomMSG(MSG msg)
        {
            // đặt tên phòng là "parameter" của "msg" khi được chuyển sang string
            string roomname = (string)msg.parameter;

            //Phát hiện các phòng trùng lặp：
            foreach (Room rm in server.roomlist)
            {
                if (rm.name == roomname)
                {
                    //Tạo phòng không thành công
                    SendIfAgreeMSG(false, "Tạo phòng không thành công do phòng có tên này đã được tạo ra");
                    return;
                }
            }
            //Không có phòng trùng lặp，có thể được tạo ra
            // Tăng số phòng 
            server.roomnum++;
            // tạo phòng mới 
            // tham số truyền vào là (số lượng phòng của server) và (tên phòng)
            // => Từ đó xác định phòng này là phòng thứ mấy 
            // => Tên phòng 
            // => Tạo 1 "listplayer" thuộc sở hữu của phòng này
            // => Tạo 1 "board" để 2 player chơi vs nhau
            Room r = new Room(server.roomnum, roomname);
            // Thêm player vào phòng = cách gửi yêu cầu vào phòng cho player này "this.player.ComeInRoom(this)"
            // Vị trí của phòng sẽ tương ứng với số lượng phòng (room.indexinroom = playerlist.Count;)
            r.AddPlayer(this.player);

            server.roomlist.Add(r);

            Broadcast b = new Broadcast(server.roomlist, Convert.ToInt32(frm.LblOnLineNum.Text), server.frm.TxtInfo.Text);
            SendBroadcastMSG(b);
            SendIfAgreeMSG(true, "CreatRoom_" + r.number.ToString());
            Thread.Sleep(1000);
            SendRoomMSG(r);
            server.UpdateListViewRoom();
        }
        private void DealComeInRoomMSG(MSG msg)
        {
            int roomnumber = Convert.ToInt32((string)msg.parameter);
            //Kiểm tra xem phòng đã đầy chưa (2 xác)
            foreach (Room r in server.roomlist)
            {
                if (r.number == roomnumber)
                {
                    if (r.playernum >= 2)
                    {
                        SendIfAgreeMSG(false, "ComeInRoom");
                        return;
                    }
                    else//Vào phòng
                    {
                        r.AddPlayer(this.player);
                        SendIfAgreeMSG(true, "ComeInRoom");
                        Thread.Sleep(1000);
                        r.SendRoomMSG();

                        server.UpdateListViewRoom();
                        return;
                    }

                }
            }
        }
        private void DealQuitRoomMSG()
        {
            foreach(Room r in server.roomlist)
            {
                if(r==player.GetRoom())
                {
                    r.SubPlayer(player);
                    //Dữ liệu kiểm tra
                    if (r.playernum == 0)
                    {
                        server.roomlist.Remove(r);
                    }
                    else
                    {
                        r.SendRoomMSG();
                    }
                    server.UpdateListViewRoom();
                    return;
                }
            }
        }

        private void DealApplyFightMSG(MSG msg)
        {
            //MessageBox.Show("rcv apply fight", "server");
            player.GetRoom().SendToPeer(player.indexinroom, msg);
        }
        private void DealRegretMSG(MSG msg)
        {
            player.GetRoom().SendToPeer(player.indexinroom, msg);
        }
        private void DealFinishMSG(MSG msg)
        {
            player.GetRoom().SendToPeer(player.indexinroom, msg);
        }
        private void DealSurrenderMSG(MSG msg)
        {
            player.GetRoom().SendToPeer(player.indexinroom, msg);
            player.GetRoom().state = false;
        }
        private void DealBoardMSG(MSG msg)
        {
            player.GetRoom().SendToPeer(player.indexinroom, msg);
        }
        private void DealIfAgreeMSG(MSG msg)
        {
            player.GetRoom().SendToPeer(player.indexinroom, msg);
            string para = (string)msg.parameter;
            string[] strs = para.Split('_');
            if(strs[0]=="True")
            {
                if(strs[1]=="Finish")
                {
                    player.GetRoom().state = false;
                }
                if(strs[1]=="ApplyFight")
                {
                    player.GetRoom().state = true;
                }
            }
        }



        public void StartListenThread()
        {
            ListenThread = new Thread(Listen);
            ListenThread.Start();
        }

        //DỪNG LUỒNG CỦA "CLIENT" BỊ XÓA ĐI KHỎI "clientlist"               DONEEE
        public void Dispose()
        {
            // .IsAlive : Trạng thái của "ListenThread"
            // Nếu "ListenThread" đã bắt đầu và chưa dùng lại hay bị dở thì = true , nếu k thì =false

            //Kiểm tra nếu luồng của "client" bị bỏ đi vẫn chạy thì đừng nó lại
            if (ListenThread != null && ListenThread.IsAlive)
            {
                //Dừng thread của "client" bị xóa đi khỏi "clientlist"
                ListenThread.Abort();
            }

        }



        private void HeartSub()
        {
            while (heart >= 0)
            {
                heart--;
                Thread.Sleep(3000);
            }
        }
        public void StartHeartSubThread()
        {
            HeartSubThread = new Thread(HeartSub);
            HeartSubThread.Start();
        }


    }
}
