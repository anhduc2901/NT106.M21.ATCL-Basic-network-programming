﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfGoServer
{
    class ConstNumber
    {
        public static int r = 15;//Bán kính

        public static int BoardSize = 600;//Kích thước bàn cờ

        public static int linenum = 19;//Bàn cờ

        public static string serverIP = "127.0.0.1";

        public static int serverport = 5171;

        public static int heart = 3;
    }
}
