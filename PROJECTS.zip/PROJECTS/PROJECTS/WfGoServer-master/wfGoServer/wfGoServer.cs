﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Windows.Forms;

namespace wfGoServer
{
    class wfGoServer
    {
        public List<Room> roomlist;
        public List<wfGoClient> clientlist;

        public bool state;

        public int roomnum;

        private TcpListener tcplistener;
        private Thread ListenThread;
        private Thread HeartCheckThread;
        private Thread BroadcastThread;

        public Form1 frm;

        // Phương thức khởi tạo vs tham số truyền vào
        public wfGoServer(Form1 f)
        {
            //list room để có thể tạo đc nhiều phòng
            roomlist = new List<Room>();

            //clientList để chứa những client kết nối vào Server
            clientlist = new List<wfGoClient>();

            // Cổng để kết nối 
            int port = ConstNumber.serverport;

            // lắng nghe tất cả IP từ 1 port cụ thể
            tcplistener = new TcpListener(IPAddress.Any, port);     

            //Trạng thái lắng nghe
            state = false;

            // Server có cái giao diện là "Form1"
            frm = f;

            // Số lượng phòng
            roomnum = 0;
        }

        // SET STATUS VÀ BẮT ĐẦU CHẠY CÁC THREAD
        public void Start()
        {
            // set status = true
            state = true;

            // gán frm.LblState.Text = "True"
            frm.LblState.BeginInvoke(new Action(() => frm.LblState.Text = "True"));  

            // Bắt đầu các tiểu trình
            StartAllThread();
        }

        
        // Tạo thread để các tiểu trình chạy // vs nhau                 DONE
        public void StartAllThread()
        {
            // Chạy cho đến khi nào tắt Server : Kiểm tra từng "client" xem có còn kết nối ko
            // Hết k nối thì cho đi ra khỏi phòng và xóa khỏi "clientlist"
            StartHeartSubThread();

            // Luồng lắng nghe các Client và "Broadcast" thông tin giao diện sang các Client
            StartListenThread();

            // GỬI THÔNG TIN CHO CÁC CLIENT  
            StartSendBroadcastThread();
            //StartPlayerNumThread();

        }

        // LUỒNG KIỂM TRA TỪNG "CLIENT" XEM CÒN ONLINE KO               DONE
        public void StartHeartSubThread()
        {
            HeartCheckThread = new Thread(HeartSub);
            HeartCheckThread.Start();
        }


        // HÀM KIỂM TRA TỪNG "CLIENT" XEM CÒN ONLINE KO                 DONE
        private void HeartSub()
        {
            // khi server vẫn còn lắng nghe
            while (state)
            {
                try
                {
                    // chạy từng (client) ở trong (clientlist)
                    foreach (wfGoClient client in clientlist)
                    {
                        // MessageBox.Show(client.heart.ToString(), "heart");
                        // (heart) là biến kiểm tra xem người chơi còn tồn tại hay không
                        if (client.heart < 0) //ngoại tuyến 
                        {
                            // xóa khỏi (ListBox1)
                            frm.ListBox1.BeginInvoke(new Action(() => frm.ListBox1.Items.Remove(client.player.name)));

                            //"Số lượng người chơi trực tuyến" - 1
                            // BeginInvoke() : thực thi cái này trong luồng xử lý và trả kết quả luôn 
                            frm.LblOnLineNum.BeginInvoke(new Action(() =>
                            {
                                int n = Convert.ToInt32(frm.LblOnLineNum.Text);
                                n--;
                                frm.LblOnLineNum.Text = n.ToString();
                            }));

                            //nếu ở trong phòng，loại bỏ khỏi phòng，Nếu số lượng phòng là 0，xóa phòng
                            // GetRoom() trả về "Room" của "client" , nếu phòng của client khác null 
                            if (client.player.GetRoom() != null)
                            {
                                // Chạy từng "Room" trong  "roomlist"
                                foreach (Room r in roomlist)
                                {
                                    // Tìm đc phòng của Cloent 
                                    if (r == client.player.GetRoom())
                                    {
                                        // Loại bỏ player 
                                        r.SubPlayer(client.player);

                                        //Dữ liệu kiểm tra : không còn người chơi
                                        if (r.playernum == 0)
                                        {
                                            // xóa phòng "r"
                                            roomlist.Remove(r);
                                            // cập nhật "ListView"
                                            UpdateListViewRoom();
                                        }
                                        // còn người chơi
                                        else
                                        {
                                            // Gửi thông tin đến cho Server cập nhật thông tin phòng còn người chơi
                                            r.SendRoomMSG();
                                        }
                                        break;
                                    }
                                }
                            }
                            // Xóa "client" có "heart <0"
                            clientlist.Remove(client);
                            // Dừng "Thread" của "client" bị xóa đi
                            client.Dispose();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                Thread.Sleep(3000); //3s
            }

        }
        // HÀM TẮT "SERVER" : SET STATUS = FALSE 
        public void End()
        {
            state = false;
            frm.LblState.BeginInvoke(new Action(() => frm.LblState.Text = "false"));
            Environment.Exit(0);
        }

        //  DONE
        private void Listen()
        {
            // bắt đầu lắng nghe các yêu cầu kết nối
            tcplistener.Start();
            
            // Kiểm tra liên tục cho đến khi tắt Server
            while (state)
            {
                // "this" : wfGoServer
                // "frm"  : wfGoServer.frm
                // Tạo ra client có ( tên = "null") (có "wfGoServer server" chính là server này - this )
                // frm    : wfGoServer frm
                wfGoClient client = new wfGoClient("null", this, frm);

                // chấp nhận client kết nối đến
                // "client" này sẽ là thằng đại diện cho "client" mà "tcpListener" lắng nghe đc
                client.tcp = tcplistener.AcceptTcpClient();

                // Client lắng nghe (Thread)
                client.StartListenThread();

                // Thread   : NO IDEAS
                client.StartHeartSubThread();
                

                // thêm client vào clientlist
                clientlist.Add(client);

                // Tham số 1 : danh sách các phòng
                // Số người online
                // Thông tin 

                // Tạo ra 1 biến kiểu "Broadcast" gồm thông tin : số người online , thông tin từ "TxtInfo.Text"
                // và danh sách phòng cho client
                Broadcast b = new Broadcast(roomlist, Convert.ToInt32(frm.LblOnLineNum.Text), frm.TxtInfo.Text);

                // Xuất thông tin "b" sang các Client
                client.SendBroadcastMSG(b);
            }
        }
        // DONE
        public void StartListenThread()
        {
            ListenThread = new Thread(Listen);
            ListenThread.Start();
        }


        //Thông báo số client đang chơi     
        private void ShowPlayerNum()
        {
            while (true)
            {
                // trì hoãn luồng này 5s
                Thread.Sleep(5000);
                MessageBox.Show(clientlist.Count.ToString(), "playernum");
            }

        }


        public void StartPlayerNumThread()
        {
            Thread t = new Thread(ShowPlayerNum);
            t.Start();
        }

        // GỬI THÔNG TIN CHO CÁC CLIENT             DONE
        private void SendBroadcast()
        {
            // Chạy vòng lặp khi Server còn lắng nghe
            while (state)
            {
                // "b" chứa dữ liệu truyền vào
                Broadcast b = new Broadcast(roomlist, Convert.ToInt32(frm.LblOnLineNum.Text), frm.TxtInfo.Text);
                // "broadcast" thông tin "b" của Server cho mỗi "client" trong "clienlist"
                foreach (wfGoClient client in clientlist)
                {                  
                    client.SendBroadcastMSG(b);
                }
                // delay luồng này 10s , cập nhật thông tin "b" từ server mỗi 10s
                Thread.Sleep(10000);
            }
        }


        //  luồng  :  SendBroadcast()               DONE
        public void StartSendBroadcastThread()
        {
            BroadcastThread = new Thread(SendBroadcast);
            BroadcastThread.Start();
        }

      
        // CẬP NHẬT LISTVIEW KHI XÓA 1 PLAYER       DONE
        public void UpdateListViewRoom()
        {

            frm.ListView1.BeginInvoke(new Action(() =>
            {
                // Xóa toàn bộ thông tin của ListView
                frm.ListView1.Items.Clear();
                // Chạy từng "Room" trong "roomlist"
                foreach (Room r in roomlist)
                {
                    // tạo 1 "item" chứa các thông tin của "Room" 
                    ListViewItem item = new ListViewItem(new string[] 
                    { r.number.ToString(), r.name, r.state.ToString(), r.playernum.ToString() });
                    // Add các thông tin đó vào ListView
                    frm.ListView1.Items.Add(item);
                }

            }));
        }


    }
}
