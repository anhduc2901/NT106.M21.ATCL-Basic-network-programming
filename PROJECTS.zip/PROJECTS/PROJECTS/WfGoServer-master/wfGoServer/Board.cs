﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Media;

namespace wfGoServer
{
    abstract class Board
    {
        protected int linenum;
        protected int size;
        protected List<Matrix> matrixlist;
        protected int number;// Số nước đi hiện tại (nước đi thứ 0 có nghĩa là không bên nào thực hiện nước đi)
        protected int cellSize;

        protected Bitmap bmp;
        private SoundPlayer soundplayer;
        //###############

        private void DrawBoard(Graphics gr)
        {
            //
            Image img = Image.FromFile(@"D:\LẬP TRÌNH MẠNG CĂN BẢN\PROJECTS\PROJECTS\WfGoClient-master\wfGoClient\Image");
            gr.DrawImage(img, 0, 0);

            //Thanh ngang
            for (int i = 1; i <= linenum; i++)
            {
                Point start = new Point(cellSize, i * cellSize);
                Point end = new Point(linenum * cellSize, i * cellSize);
                gr.DrawLine(Pens.Black, start, end);
            }
            // Thanh dọc
            for (int i = 1; i <= linenum; i++)
            {
                Point start = new Point(i * cellSize, cellSize);
                Point end = new Point(i * cellSize, linenum * cellSize);
                gr.DrawLine(Pens.Black, start, end);
            }
            //
            for (int i = 1; i <= linenum; i++)
            {
                string drawstr = i.ToString();
                Font drawfont = new Font("Nhà Tống", 12);
                SolidBrush drawbrush = new SolidBrush(Color.Black);
                PointF drawpointf = new PointF((float)(i * cellSize) - 10, 0);
                gr.DrawString(drawstr, drawfont, drawbrush, drawpointf);
            }
            //Trục Y
            for (int i = 1; i <= linenum; i++)
            {
                string drawstr = i.ToString();
                Font drawfont = new Font("Nhà Tống", 12);
                SolidBrush drawbrush = new SolidBrush(Color.Black);
                PointF drawpointf = new PointF(0, (float)(i * cellSize) - 10);
                gr.DrawString(drawstr, drawfont, drawbrush, drawpointf);
            }
            //9 chấm nhỏ
            for (int i = 4; i <= 16; i += 6)
            {
                for (int j = 4; j <= 16; j += 6)
                {
                    int X = i * cellSize;
                    int Y = j * cellSize;

                    int width = cellSize / 4;
                    int height = width;

                    int circleX = X - width / 2;
                    int circleY = Y - height / 2;

                    gr.FillEllipse(Brushes.Black, circleX, circleY, width, height);


                }
            }
        }

        private void DrawPieces(Graphics gr)
        {
            int n = linenum + 1;
            for(int i=1;i<n;i++)
            {
                for(int j=1;j<n;j++)
                {
                    if(matrixlist[number][i,j]!=0)
                    {
                        bool isblack = true;
                        if(matrixlist[number][i,j]<0)
                        {
                            isblack = false;
                        }
                        DrawPiece(gr, isblack, i, j);
                    }
                }
            }
        }

        private void DrawPiece(Graphics gr,bool isblack,int x,int y)
        {
            int r = ConstNumber.r;
            Color color = isblack == true ? Color.Black : Color.White;
            Brush mybrush = new SolidBrush(color);

            int rectX = x * 2 * r - r;
            int rectY = y * 2 * r - r;

            gr.FillEllipse(mybrush, rectX, rectY, 2 * r, 2 * r);
            gr.DrawEllipse(Pens.Black, rectX, rectY, 2 * r, 2 * r);
        }

        private bool SetPiece(bool isblack, int x, int y)
        {
            //
            if (matrixlist[number][x, y] != 0)
            {
                return false;
            }

            //
            Matrix m = matrixlist[number].Copy();
            number = number + 1;
            int flag = 1;
            if (isblack == false)
            {
                flag = -1;
            }
            m[x, y] = flag * number;
            matrixlist.Add(m);

            soundplayer.SoundLocation = @"D:\LẬP TRÌNH MẠNG CĂN BẢN\PROJECTS\PROJECTS\WfGoClient-master\wfGoClient\Sound";
            soundplayer.Play();

            return true;

        }

        //################

        public Board()
        {
            size = ConstNumber.BoardSize;
            linenum = ConstNumber.linenum;
            cellSize = 2 * ConstNumber.r;

            number = 0;
            matrixlist = new List<Matrix>();


            Matrix m = new Matrix();
            matrixlist.Add(m);

            bmp = new Bitmap(size, size);
            soundplayer = new SoundPlayer();
        }

        public virtual void Draw(Graphics gr)
        {
            gr.DrawImage(bmp, 0, 0);
        }

        public void DrawToBmp()
        {
            Graphics grbmp = Graphics.FromImage(bmp);
            DrawBoard(grbmp);
            DrawPieces(grbmp);
        }

        public bool SetBlackPiece(int x, int y)
        {
            return SetPiece(true, x, y);
        }

        public bool SetWhitePiece(int x, int y)
        {
            return SetPiece(false, x, y);
        }

        public bool RemovePiece(int x, int y)
        {
            //Không có con tốt nào ở vị trí này
            if (matrixlist[number][x, y] == 0)
            {
                return false;
            }
            //Co quan co，go bo no
            int num = matrixlist[number][x, y];
            matrixlist[number][x, y] = 0;

            return false;

        }

        public virtual void Regret()
        {

        }

    }

}
