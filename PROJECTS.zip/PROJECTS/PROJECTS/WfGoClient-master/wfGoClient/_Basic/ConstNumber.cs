﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wfGoClient
{
    class ConstNumber
    {
        public static int r = 15;

        public static int BoardSize = 600; 

        public static int linenum = 19;    

        public static string serverIP = "127.0.0.1";

        public static int serverport = 5171;
    }
}
