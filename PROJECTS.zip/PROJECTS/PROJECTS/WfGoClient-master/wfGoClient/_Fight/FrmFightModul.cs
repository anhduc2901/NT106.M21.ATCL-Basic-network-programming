﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfGoClient
{
    public partial class FrmFightModul : Form
    {
        public FrmFightModul()
        {
            InitializeComponent();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        // I'm here
        private void FrmFightModul_Load(object sender, EventArgs e)
        {
            FrmStart.client.frmfightmodul = this;
            FrmStart.main.Hide();
        }

        private void PicShow_Paint(object sender, PaintEventArgs e)
        {
            if (FrmStart.client.board != null)
                FrmStart.client.board.Draw(e.Graphics);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FrmStart.client.SendApplyFightMSG(20);
        }

        private void FrmFightModul_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult res = MessageBox.Show("Rời khỏi phòng？", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                FrmStart.client.SendQuitRoomMSG();
                FrmStart.main.Show();
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            FrmStart.client.SendRegretMSG();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            FrmStart.client.SendFinishMSG();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            FrmStart.client.SendSurrenderMSG();
        }

        private int GetUpperNum(double a)//làm tròn
        {
            int b = (int)a;
            if (b < a) b = b + 1; //Nếu số làm tròn nhỏ hơn số ban đầu，sau khi làm tròn+1
            return b;

        }

        private void PicShow_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            if (FrmStart.client.right == false) return;
            //Tính tọa độ ngang và dọc
            int cellSize = ConstNumber.r * 2;
            int boardsize = ConstNumber.BoardSize;

            //Theo vị trí bấm chuột，Tính toạ độ theo phương ngang và phương thẳng đứng của quân cờ
            double dbX = e.X * 1.0 / cellSize - 0.5;
            int intX = GetUpperNum(dbX);
            double dbY = e.Y * 1.0 / cellSize - 0.5;
            int intY = GetUpperNum(dbY);//làm tròn
                                        //Trả về nếu vị trí được nhấp không nằm trong phạm vi bàn cờ
            if (intX > boardsize || intY > boardsize) return;
            if (intX == 0 || intY == 0) return;

            if (FrmStart.client.player.isblack)
            {
                FrmStart.client.board.SetBlackPiece(intX, intY);
            }
            else
            {
                FrmStart.client.board.SetWhitePiece(intX, intY);
            }
            PicShow.Invalidate();
            FrmStart.client.right = false;
            FrmStart.client.SendBoardMSG();



        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {

        }
    }
}
