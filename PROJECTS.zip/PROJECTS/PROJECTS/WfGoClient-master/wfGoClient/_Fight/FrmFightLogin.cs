﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfGoClient
{
    public partial class FrmFightLogin : Form
    {
        public FrmFightLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            // Đầu vào có được phát hiện không
            if (TxtUserID.Text == "")
            {
                MessageBox.Show("Vui lòng nhập tên người dùng！", "Chú ý", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (TxtPwd.Text == "")
            {
                MessageBox.Show("Vui lòng điền lại mật khẩu của bạn！", "Chú ý", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Phát hiện hợp lệ tên người dùng và mật khẩu
            if (TxtUserID.Text.Length < 3)
            {
                MessageBox.Show("Tên người dùng hoặc mật khẩu sai！", "Chú ý ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (TxtPwd.Text != "123")
            {
                MessageBox.Show("Tên người dùng hoặc mật khẩu sai！", "Chú ý ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // hợp lệ, nhập

            
            // Tạo 1 client với tham số truyền vào là string (PlayerName=string)
            FrmStart.client = new wfGoClient(TxtUserID.Text);

            // Connect vs server bằng ip và port cụ thể
            FrmStart.client.Connect();

            // Tham số truyền vào là string (string này sẽ đc gán cho object của MSG)-MSG dùng để xác định 
            FrmStart.client.SendNameMSG(TxtUserID.Text);

            //Lắng nghe các luồng stream đc gửi đến
            FrmStart.client.StartListenThread();

            // Gửi các luồng stream đi nếu có
            FrmStart.client.StartSendHeartbeatThread();

            // Tạo 1 form mới với tham số truyền vào là "TxtUserID.Text"
            FrmStart.main = new FrmFightMain(TxtUserID.Text);

            // main : "FrmFightMain" Form để tạo và vào phòng
            FrmStart.main.Show();


            this.Close();

        }

        private void FrmFightLogin_Load(object sender, EventArgs e)
        {
            TxtUserID.Text = "EnterUserName";
            TxtPwd.Text = "123";
        }

        private void linkLabelRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabelForgetPwd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
